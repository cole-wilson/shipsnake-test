# ShipSnake
A quick and easy way to distribute your python projects!

long_desc
### Installation
##### Pip:
run `pip3 install shipsnake`

### Usage
### Contributors
 - Cole Wilson
### Contact
<cole@colewilson.xyz>